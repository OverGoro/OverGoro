#ifndef STACK_DEF_H__
#define STACK_DEF_H__

#define STATIC_STACK_SIZE 10000 

#endif // !STACK_DEF_H__
